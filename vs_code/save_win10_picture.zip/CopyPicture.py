#! python3

import os
import shutil

def CopyPicture():
	path = 'C:\\Users\\pactera\\AppData\\Local\\Packages\\Microsoft.Windows.ContentDeliveryManager_cw5n1h2txyewy\\LocalState\\Assets'
	#os.path.dirname(path)
	
	for filename in os.listdir(path):
		#拼接路径与文件名
		path_file = os.path.join(path,filename)
		#print(str(os.path.getsize(path_file))+'\t', filename)
		#判断文件大小
		if os.path.getsize(path_file) > 169*1024:
			#复制并重新命名文件
			shutil.copy(path_file, 'D:\\win_screen\\tmp\\'+str(filename)+'.jpg')   
		

if __name__ == '__main__':
	CopyPicture()